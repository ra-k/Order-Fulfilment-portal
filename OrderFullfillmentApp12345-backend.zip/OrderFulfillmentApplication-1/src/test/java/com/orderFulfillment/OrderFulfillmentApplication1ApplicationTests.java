package com.orderFulfillment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrderFulfillmentApplication1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
