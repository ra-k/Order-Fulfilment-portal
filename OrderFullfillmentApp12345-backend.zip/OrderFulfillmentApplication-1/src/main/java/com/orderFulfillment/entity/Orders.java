package com.orderFulfillment.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

import org.springframework.boot.autoconfigure.AutoConfiguration;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
@Entity
public class Orders {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer id;
	public Integer getId() {
		return id;
	}


	public void setId(Integer id) {
		this.id = id;
	}


	private String account;
	private String due_date;
	@OneToOne(cascade = CascadeType.ALL ,fetch=FetchType.EAGER )
	private Product product;
	
	
	
	public Orders(String account, String due_date, Product product) {
		super();
		this.account = account;
		this.due_date = due_date;
		this.product = product;
	}
	
	
	public Orders() {
		super();
		// TODO Auto-generated constructor stub
	}


	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getDue_date() {
		return due_date;
	}
	public void setDue_date(String due_date) {
		this.due_date = due_date;
	}
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}


	@Override
	public String toString() {
		return "Orders [account=" + account + ", due_date=" + due_date + ", product=" + product + "]";
	}
	
	
	
	
	
	
	
}
