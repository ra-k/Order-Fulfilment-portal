package com.orderFulfillment.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.orderFulfillment.entity.Orders;
import com.orderFulfillment.repo.OrderRepo;

@Service
public class OrdersService {
	
	@Autowired
	private OrderRepo orderRepo;
	
	public Orders save(Orders order)
	{
		return orderRepo.save(order);
	}


}
