package com.orderFulfillment.controller;


import java.io.File;



import java.io.FileOutputStream;
import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;


import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.orderFulfillment.entity.Orders;
import com.orderFulfillment.service.OrdersService;
@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/v1/")
public class Controller {
	@Value("${file.upload-dir}")
	String FILE_DIRECTORY;
	
	@Autowired
	private OrdersService ordersService;
	
	@PostMapping("/upload-file")
	
	public ResponseEntity<?> fileupload(@RequestParam("file")MultipartFile file) throws IOException{
		System.out.println("Connection created");
		try {
			//validation
			if(file.isEmpty()) {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Request must contain file");
			}
			//
			if(!file.getContentType().equals("application/xml")) {
				return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Must be in xml form ");	
			}
			
		File myfile=new File(FILE_DIRECTORY+file.getOriginalFilename());
		myfile.createNewFile();
		FileOutputStream fos=new FileOutputStream(myfile);
		fos.write(file.getBytes());
		fos.close();
		ObjectMapper mapper=new XmlMapper();
		File xmlfile= new File((FILE_DIRECTORY+file.getOriginalFilename()));
		TypeReference<Orders> typeReference= new TypeReference<Orders>() {};
		Orders ordermapper= mapper.readValue(xmlfile, typeReference);
		System.out.println(ordermapper.getAccount()+" "+ordermapper.getDue_date()+" "+ordermapper.getProduct().getId()
				+" "+ordermapper.getProduct().getCategory()+" "+ordermapper.getProduct().getName()+" "+ordermapper.getProduct().getQuantity());
		
		Orders order= new Orders();
		order.setAccount(ordermapper.getAccount());
		order.setDue_date(ordermapper.getDue_date());
		order.setProduct(ordermapper.getProduct());
		
		Orders save= ordersService.save(order);
		
		
		return new ResponseEntity<Orders>(save,HttpStatus.OK);
		
		}catch (Exception e) {
			e.printStackTrace();
		}
	
		return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).
				body("something went wrong! Try again..");
	}

}
